drop database if exists `gblists`;
create database if not exists `gblists`;
use `gblists`;

drop table if exists `glist`;

create table `glist` (
	`uid` integer NOT NULL,
	`id` integer NOT NULL,
    `count` integer NOT NULL,
    PRIMARY KEY (`uid`)
);

drop table if exists `blist`;

create table `blist` (
	`uid` integer NOT NULL,
	`id` integer NOT NULL,
    `count` integer NOT NULL,
    PRIMARY KEY (`uid`)
);

load data local infile 'C:\\Users\\mnoor\\Downloads\\glistpy.csv'
into table gblists.glist fields terminated by ','
lines terminated by '\n';

load data local infile 'C:\\Users\\mnoor\\Downloads\\blistpy.csv'
into table gblists.blist fields terminated by ','
lines terminated by '\n';