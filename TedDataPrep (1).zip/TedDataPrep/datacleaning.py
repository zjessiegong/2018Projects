# -*- coding: utf-8 -*-
"""
Created on Sun Feb 18 16:28:40 2018

@author: jessi
"""

import pandas as pd
import datetime
import numpy as np
import seaborn as sns
import ast

df = pd.read_csv('E:/MSBA/Data Visualization/ted_main.csv')

df.head(5)

def get_year(date):
    return int(datetime.datetime.utcfromtimestamp(date).strftime('%Y'))

def get_half_of_day(date):
    h = int(datetime.datetime.utcfromtimestamp(date).strftime('%H'))
    if (h > 12):
        return 1
    else:
        return 0

def get_month(date):
    return int(datetime.datetime.utcfromtimestamp(date).strftime('%m'))

df['year'] = df['film_date'].apply(get_year)
df['month'] = df['film_date'].apply(get_month)
df['half_of_day'] = df['film_date'].apply(get_half_of_day)

temp_df = df[df['year'] > 2000]
sns.set(rc={'figure.figsize':(11.7,8.27)})
sns.barplot(x=temp_df['year'], y=temp_df['comments'],hue=temp_df['half_of_day'], estimator=np.sum)

rating_names = set([])

# Method to read get a list of rating "names".
def split_ratings(ratings):
    val = ast.literal_eval(ratings)
    for rating in val:
        rating_names.add(rating['name'])
df['ratings'].apply(split_ratings)

def get_count_from_ratings(ratings, col_name):
    val = ast.literal_eval(ratings)
    for rating in val:
        if rating['name'] == col_name:
            return rating['count']
for name in rating_names:
    df[name] = df['ratings'].apply(lambda rating : get_count_from_ratings(rating, col_name=name))
#  Let us take another look at the updated dataframe now.
df.head(5)

e = df['year']
f = df['month']
df1 = df
df1.assign(Year=e.values, Month=f.values)

df1.to_csv("ted_data.csv")



    