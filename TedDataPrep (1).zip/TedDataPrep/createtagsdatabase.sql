drop database if exists `tags`;
create database if not exists `tags`;
use `tags`;

drop table if exists `tab`;

create table `tab` (
	`uid` integer NOT NULL,
	`id` integer NOT NULL,
    `tag` varchar(50) NOT NULL,
    PRIMARY KEY (`uid`)
);

load data local infile 'C:\\Users\\mnoor\\Downloads\\Tags.csv'
into table tags.tab fields terminated by ','
lines terminated by '\n';