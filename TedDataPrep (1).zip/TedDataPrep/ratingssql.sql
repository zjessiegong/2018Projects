SELECT id, sum(count) as sum
FROM gblists.glist
GROUP BY id;

SELECT id, sum(count) as sum
FROM gblists.blist
GROUP BY id;