SELECT * FROM tags.tab;

SELECT id, COUNT(id) as NumTags
FROM tags.tab
GROUP BY id;